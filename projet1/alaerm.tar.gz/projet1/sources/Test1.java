public class Test1 {
    public static void main(String [] args) {
        System.out.println(new Rationnel(3, 4, 5)) ;
        System.out.println(new Rationnel(5, 4, 3)) ;
        System.out.println(new Rationnel(-2, 3)) ;
        System.out.println(new Rationnel(3, -2)) ;
        System.out.println(new Rationnel(3, 6, -2)) ;
        System.out.println(new Rationnel(3)) ;
        System.out.println(new Rationnel(1,3)) ;
    }
}
