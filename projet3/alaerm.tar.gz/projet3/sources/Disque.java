/** Un Disque est un objet ayant un diamètre */
public interface Disque 
{
    /** Méthode donnant le diamètre du disque */
    int diametre() ;    
}
